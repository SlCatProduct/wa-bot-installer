# WhatsApp Bot Admin (Advanced, Dockerized)

## Run
```bash
docker compose up --build -d
# then open http://<server-ip>:3000
```
Volumes map DB and WA auth to the host for persistence.

Dev without Docker:
- Backend: `cd backend && npm install && npm start`
- Frontend: `cd frontend && npm install && npm run dev` (proxies /api to 3000)

APIs:
- GET /api/status, /api/qr, /api/messages, /api/logs
- POST /api/messages  { phone, message, sendAt }
- POST /api/messages/:id/send-now
- PUT/DELETE /api/messages/:id