import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import Database from 'better-sqlite3';
import dayjs from 'dayjs';
import qrcode from 'qrcode';

import pkg from 'whatsapp-web.js';
const { Client, LocalAuth } = pkg;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const db = new Database(path.join(__dirname, 'data.sqlite'));
db.exec(`
CREATE TABLE IF NOT EXISTS scheduled_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phone TEXT NOT NULL,
  message TEXT NOT NULL,
  send_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  sent_at TEXT,
  fail_reason TEXT
);
CREATE TABLE IF NOT EXISTS sent_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scheduled_id INTEGER,
  phone TEXT,
  message TEXT,
  send_at TEXT,
  status TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY(scheduled_id) REFERENCES scheduled_messages(id)
);
`);

let lastQRText = null;
let isReady = false;

const waClient = new Client({
  puppeteer: {
    headless: true,
    args: ['--no-sandbox','--disable-setuid-sandbox']
  },
  authStrategy: new LocalAuth({
    dataPath: path.join(__dirname, 'wa-auth')
  })
});

waClient.on('qr', (qr) => { lastQRText = qr; console.log('[WA] QR received'); });
waClient.on('ready', () => { isReady = true; lastQRText = null; console.log('[WA] Ready'); });
waClient.on('disconnected', (r) => { isReady = false; console.warn('[WA] Disconnected:', r); });
waClient.on('auth_failure', (m) => { isReady = false; console.error('[WA] Auth failure:', m); });

waClient.initialize().catch(e => console.error('[WA] init error', e));

function phoneToJid(phone) {
  const digits = String(phone).replace(/[^\d]/g, '');
  return `${digits}@c.us`;
}
async function sendWhatsApp(phone, message) {
  if (!isReady) throw new Error('WhatsApp client not ready');
  const jid = phoneToJid(phone);
  const res = await waClient.sendMessage(jid, message);
  return { id: res?.id?._serialized || null };
}
function markSent(id) {
  const now = new Date().toISOString();
  db.prepare('UPDATE scheduled_messages SET status=?, sent_at=?, fail_reason=NULL WHERE id=?').run('sent', now, id);
  const row = db.prepare('SELECT * FROM scheduled_messages WHERE id=?').get(id);
  db.prepare('INSERT INTO sent_logs (scheduled_id, phone, message, send_at, status) VALUES (?,?,?,?,?)')
    .run(id, row.phone, row.message, row.send_at, 'sent');
}
function markFailed(id, reason) {
  const now = new Date().toISOString();
  db.prepare('UPDATE scheduled_messages SET status=?, sent_at=?, fail_reason=? WHERE id=?').run('failed', now, String(reason), id);
  const row = db.prepare('SELECT * FROM scheduled_messages WHERE id=?').get(id);
  db.prepare('INSERT INTO sent_logs (scheduled_id, phone, message, send_at, status) VALUES (?,?,?,?,?)')
    .run(id, row.phone, row.message, row.send_at, 'failed');
}

setInterval(async () => {
  try {
    if (!isReady) return;
    const now = new Date().toISOString();
    const due = db.prepare("SELECT * FROM scheduled_messages WHERE status='pending' AND send_at <= ? ORDER BY send_at ASC LIMIT 50").all(now);
    for (const m of due) {
      try {
        await sendWhatsApp(m.phone, m.message);
        markSent(m.id);
        console.log(`[SENT] #${m.id} -> ${m.phone}`);
      } catch (e) {
        markFailed(m.id, e?.message || e);
        console.error(`[FAIL] #${m.id} -> ${m.phone}:`, e);
      }
      await new Promise(r => setTimeout(r, 700));
    }
  } catch (e) {
    console.error('Scheduler error', e);
  }
}, 30000);

app.get('/api/status', (req,res) => res.json({ whatsapp_ready: isReady, has_qr: !!lastQRText }));
app.get('/api/qr', async (req,res) => {
  try {
    if (!lastQRText) return res.json({ qrDataUrl: null });
    const dataUrl = await qrcode.toDataURL(lastQRText);
    res.json({ qrDataUrl: dataUrl });
  } catch { res.status(500).json({ error: 'QR gen failed' }); }
});
app.get('/api/messages', (req,res) => {
  const rows = db.prepare('SELECT * FROM scheduled_messages ORDER BY send_at DESC').all();
  res.json(rows);
});
app.post('/api/messages', (req,res) => {
  const { phone, message, sendAt } = req.body || {};
  if (!phone || !message || !sendAt) return res.status(400).json({ error: 'phone, message, sendAt required' });
  const norm = String(phone).replace(/[^\d+]/g, '');
  const dt = dayjs(sendAt);
  if (!dt.isValid()) return res.status(400).json({ error: 'Invalid sendAt' });
  const info = db.prepare('INSERT INTO scheduled_messages (phone, message, send_at) VALUES (?,?,?)').run(norm, message, dt.toISOString());
  res.json({ id: info.lastInsertRowid });
});
app.put('/api/messages/:id', (req,res) => {
  const id = Number(req.params.id);
  const ex = db.prepare('SELECT * FROM scheduled_messages WHERE id=?').get(id);
  if (!ex) return res.status(404).json({ error: 'not found' });
  const phone = req.body.phone !== undefined ? String(req.body.phone).replace(/[^\d+]/g, '') : ex.phone;
  const message = req.body.message !== undefined ? String(req.body.message) : ex.message;
  const sendAt = req.body.sendAt !== undefined ? String(req.body.sendAt) : ex.send_at;
  const status = req.body.status !== undefined ? String(req.body.status) : ex.status;
  db.prepare('UPDATE scheduled_messages SET phone=?, message=?, send_at=?, status=? WHERE id=?').run(phone, message, sendAt, status, id);
  res.json({ ok: true });
});
app.delete('/api/messages/:id', (req,res) => {
  const id = Number(req.params.id);
  db.prepare('DELETE FROM scheduled_messages WHERE id=?').run(id);
  res.json({ ok: true });
});
app.post('/api/messages/:id/send-now', async (req,res) => {
  const id = Number(req.params.id);
  const row = db.prepare('SELECT * FROM scheduled_messages WHERE id=?').get(id);
  if (!row) return res.status(404).json({ error: 'not found' });
  try {
    await sendWhatsApp(row.phone, row.message);
    markSent(id);
    res.json({ ok: true });
  } catch (e) {
    markFailed(id, e?.message || e);
    res.status(500).json({ error: 'send failed', reason: e?.message || String(e) });
  }
});
app.get('/api/logs', (req,res) => {
  const { status, limit='100' } = req.query;
  let sql = 'SELECT * FROM sent_logs';
  const params = [];
  if (status) { sql += ' WHERE status=?'; params.push(status); }
  sql += ' ORDER BY id DESC LIMIT ?'; params.push(Number(limit)||100);
  const rows = db.prepare(sql).all(...params);
  res.json(rows);
});

const webDir = path.join(__dirname, 'web');
app.use(express.static(webDir));
app.get('*', (req,res) => {
  try { res.sendFile(path.join(webDir, 'index.html')); }
  catch { res.status(200).send('Backend running.'); }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));