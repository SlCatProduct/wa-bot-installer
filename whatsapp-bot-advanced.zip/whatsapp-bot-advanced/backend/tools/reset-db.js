import path from 'path';
import { fileURLToPath } from 'url';
import Database from 'better-sqlite3';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database(path.join(__dirname, '..', 'data.sqlite'));
db.exec(`DELETE FROM scheduled_messages; DELETE FROM sent_logs; VACUUM;`);
console.log('DB cleared.');