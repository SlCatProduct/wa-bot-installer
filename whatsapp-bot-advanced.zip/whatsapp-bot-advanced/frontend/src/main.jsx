import React, { Suspense } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'

// Styles (keep your existing styles.css too if you have it)

import './styles.css'

// ---- 1) Early theme boot (persist + no flash) ----
(function bootTheme() {
  try {
    const saved = localStorage.getItem('theme')
    const prefers = window.matchMedia('(prefers-color-scheme: dark)').matches
    const dark = saved ? saved === 'dark' : prefers
    const root = document.documentElement
    root.classList.toggle('dark', dark)
    root.style.colorScheme = dark ? 'dark' : 'light'
  } catch {}
})()

// ---- 2) Error Boundary with friendly fallback ----
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false, error: null }
  }
  static getDerivedStateFromError(error) { return { hasError: true, error } }
  componentDidCatch(error, info) { console.error('[App ErrorBoundary]', error, info) }
  render() {
    if (!this.state.hasError) return this.props.children
    const msg = (this.state.error && this.state.error.message) || 'Unexpected error'
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-neutral-900">
        <div className="card max-w-lg text-center">
          <div className="text-2xl font-semibold mb-2">Something went wrong</div>
          <div className="text-sm text-gray-600 dark:text-neutral-300 mb-4">{msg}</div>
          <div className="flex items-center justify-center gap-2">
            <button className="btn" onClick={() => location.reload()}>Reload</button>
            <button
              className="btn-secondary"
              onClick={() => {
                try {
                  navigator.clipboard.writeText(String(this.state.error || ''))
                } catch {}
              }}
              title="Copy error"
            >
              Copy error
            </button>
          </div>
        </div>
      </div>
    )
  }
}

// ---- 3) Minimal Suspense fallback (spinner) ----
function Fallback() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-neutral-900">
      <div className="flex items-center gap-3 text-gray-600 dark:text-neutral-300">
        <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24" fill="none">
          <circle className="opacity-30" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
          <path d="M22 12a10 10 0 0 1-10 10" stroke="currentColor" strokeWidth="4" strokeLinecap="round"/>
        </svg>
        <span>Loading…</span>
      </div>
    </div>
  )
}

// ---- 4) Toast overlay (provider) ----
import Toaster from './components/Toaster.jsx'

// Create root & render
const root = createRoot(document.getElementById('root'))
root.render(
  <React.StrictMode>
    <ErrorBoundary>
      <Suspense fallback={<Fallback />}>
        <App />
        <Toaster />
      </Suspense>
    </ErrorBoundary>
  </React.StrictMode>
)
