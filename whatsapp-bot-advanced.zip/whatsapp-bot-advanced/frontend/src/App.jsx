import { useEffect, useMemo, useState } from "react";
import StatusCard from "./components/StatusCard.jsx";
import QRCard from "./components/QRCard.jsx";
import SchedulerForm from "./components/SchedulerForm.jsx";
import ScheduleTable from "./components/ScheduleTable.jsx";
import Logs from "./components/Logs.jsx";

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [active, setActive] = useState("dashboard"); // 'dashboard' | 'schedule' | 'logs' | 'settings'
  const [status, setStatus] = useState({ whatsapp_ready: false, has_qr: false });
  const [msgs, setMsgs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);
  const [dark, setDark] = useState(() =>
    typeof window !== "undefined" ? document.documentElement.classList.contains("dark") : false
  );

  const loadAll = async () => {
    try {
      setErr(null);
      setLoading(true);
      const [s, m] = await Promise.all([
        fetch("/api/status").then((r) => r.json()),
        fetch("/api/messages").then((r) => r.json()),
      ]);
      setStatus(s || { whatsapp_ready: false, has_qr: false });
      setMsgs(Array.isArray(m) ? m : []);
    } catch (e) {
      console.error(e);
      setErr("Failed to load dashboard data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAll();
    const onFocus = () => loadAll();
    const onReload = () => loadAll();
    window.addEventListener("focus", onFocus);
    document.addEventListener("reload-schedules", onReload);
    const t = setInterval(loadAll, 7000);
    return () => {
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("reload-schedules", onReload);
      clearInterval(t);
    };
  }, []);

  // KPIs
  const kpi = useMemo(() => {
    const total = msgs.length;
    const pending = msgs.filter((x) => x.status === "pending").length;
    const sent = msgs.filter((x) => x.status === "sent").length;
    const failed = msgs.filter((x) => x.status === "failed").length;
    const nextAt = msgs
      .filter((x) => x.status === "pending")
      .map((x) => new Date(x.send_at))
      .sort((a, b) => a - b)[0];
    return { total, pending, sent, failed, nextAt };
  }, [msgs]);

  const toggleTheme = () => {
    const root = document.documentElement;
    root.classList.toggle("dark");
    setDark(root.classList.contains("dark"));
  };

  const NavButton = ({ id, label }) => (
    <button
      onClick={() => {
        setActive(id);
        setSidebarOpen(false);
      }}
      className={`w-full text-left px-3 py-2 rounded-xl mb-1 ${
        active === id
          ? "bg-indigo-600 text-white"
          : "hover:bg-gray-50 dark:hover:bg-neutral-800 text-gray-700 dark:text-neutral-200"
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-neutral-900 dark:text-neutral-100">
      {/* Top bar */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/80 dark:bg-neutral-900/80 border-b border-gray-200 dark:border-neutral-800">
        <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="md:hidden inline-flex items-center justify-center rounded-lg border border-gray-200 dark:border-neutral-700 p-2"
              aria-label="Toggle sidebar"
            >
              <svg width="20" height="20" fill="currentColor">
                <path
                  d="M3 6h14M3 10h14M3 14h14"
                  stroke="currentColor"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                />
              </svg>
            </button>
            <div className="h-8 w-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-blue-500" />
            <div>
              <div className="font-semibold">Whatsapp Bot Admin Panel</div>
              <div className="text-xs text-gray-500 dark:text-neutral-400">Dashboard</div>
            </div>
            <span
              className={`ml-3 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs ${
                status.whatsapp_ready
                  ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300"
                  : "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300"
              }`}
            >
              <span
                className={`inline-block h-2 w-2 rounded-full ${
                  status.whatsapp_ready ? "bg-emerald-500" : "bg-amber-500"
                }`}
              ></span>
              {status.whatsapp_ready ? "Connected" : "Not connected"}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={loadAll}
              className="hidden md:inline-flex items-center gap-2 rounded-lg border border-gray-200 dark:border-neutral-700 px-3 py-2 hover:bg-gray-50 dark:hover:bg-neutral-800"
              title="Refresh"
            >
              <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.6">
                <path d="M4 4v4h4M20 20v-4h-4" />
                <path d="M6 14a6 6 0 0 0 10 2m2-6A6 6 0 0 0 8 4" />
              </svg>
              Refresh
            </button>
            <button
              onClick={toggleTheme}
              className="inline-flex items-center gap-2 rounded-lg border border-gray-200 dark:border-neutral-700 px-3 py-2 hover:bg-gray-50 dark:hover:bg-neutral-800"
              title="Theme"
            >
              {dark ? (
                <>
                  <svg width="18" height="18" fill="currentColor">
                    <path d="M9 1a8 8 0 1 0 8 8A7 7 0 0 1 9 1Z" />
                  </svg>{" "}
                  Light
                </>
              ) : (
                <>
                  <svg width="18" height="18" fill="currentColor">
                    <path d="M9 4.5a.75.75 0 0 1 .75.75V7a.75.75 0 0 1-1.5 0V5.25A.75.75 0 0 1 9 4.5Z" />
                    <path d="M9 11a2 2 0 1 0-2-2 2 2 0 0 0 2 2Z" />
                    <path d="M9 13.5a.75.75 0 0 1 .75.75V15a.75.75 0 0 1-1.5 0v-.75A.75.75 0 0 1 9 13.5Z" />
                  </svg>{" "}
                  Dark
                </>
              )}
            </button>
          </div>
        </div>

        {/* connection helper banner */}
        {!status.whatsapp_ready && (
          <div className="bg-amber-50 dark:bg-amber-900/20 border-t border-amber-200 dark:border-amber-800">
            <div className="mx-auto max-w-7xl px-4 py-2 text-sm text-amber-800 dark:text-amber-200">
              Not connected. Open <b>Linked Devices → Link a device</b> on your phone and scan the QR.
            </div>
          </div>
        )}
      </header>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/30 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Layout */}
      <div className="mx-auto max-w-7xl px-4 py-6 grid grid-cols-1 md:grid-cols-[240px_1fr] gap-6">
        {/* Sidebar */}
        <aside
          className={`${
            sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
          } md:static fixed z-40 top-16 left-0 h-[calc(100vh-4rem)] md:h-auto w-64 md:w-auto transition-transform`}
        >
          <nav className="rounded-2xl border border-gray-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 p-2 md:sticky md:top-20">
            <NavButton id="dashboard" label="Dashboard" />
            <NavButton id="schedule" label="Scheduler" />
            <NavButton id="logs" label="Logs" />
            <NavButton id="settings" label="Settings" />
          </nav>

          {/* KPIs */}
          <div className="mt-6 space-y-3">
            <div className="kpi-card">
              <div className="kpi-label">Total</div>
              <div className="kpi-value">{kpi.total}</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-label">Pending</div>
              <div className="kpi-value">{kpi.pending}</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-label">Sent</div>
              <div className="kpi-value">{kpi.sent}</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-label">Failed</div>
              <div className="kpi-value">{kpi.failed}</div>
            </div>
            <div className="kpi-card">
              <div className="kpi-label">Next send</div>
              <div className="text-sm">
                {kpi.nextAt ? kpi.nextAt.toLocaleString() : <span className="text-gray-400">—</span>}
              </div>
            </div>
          </div>
        </aside>

        {/* Main */}
        <main className="space-y-6">
          {err && (
            <div className="rounded-xl border border-red-200 bg-red-50 text-red-700 px-3 py-2 text-sm">
              {err}
            </div>
          )}

          {/* Dashboard */}
          {active === "dashboard" && (
            <>
              <div className="grid md:grid-cols-2 gap-6">
                <StatusCard />
                <QRCard />
              </div>

              <div className="card">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold">Quick Actions</h2>
                  <button
                    onClick={loadAll}
                    className="btn-secondary"
                  >
                    {loading ? "Syncing…" : "Refresh now"}
                  </button>
                </div>
                <div className="mt-3 text-sm text-gray-600 dark:text-neutral-300">
                  {loading ? "Syncing data…" : "Up to date."}
                </div>
              </div>
            </>
          )}

          {/* Scheduler */}
          {active === "schedule" && (
            <>
              <div className="card">
                <h2 className="text-lg font-semibold mb-3">Create a Scheduled Message</h2>
                <SchedulerForm />
              </div>
              <ScheduleTable />
            </>
          )}

          {/* Logs */}
          {active === "logs" && <Logs />}

          {/* Settings */}
          {active === "settings" && (
            <div className="card">
              <h2 className="text-lg font-semibold mb-4">Settings</h2>
              <ul className="space-y-2 text-sm text-gray-600 dark:text-neutral-300">
                <li>
                  • Theme:{" "}
                  <button onClick={toggleTheme} className="underline">
                    Toggle {dark ? "Light" : "Dark"}
                  </button>
                </li>
                <li>
                  • Timezone is controlled by container env{" "}
                  <code className="px-1 rounded bg-gray-100 dark:bg-neutral-800">TZ</code>.
                </li>
                <li>• Port exposed by installer’s compose override (Change via installer menu).</li>
              </ul>
            </div>
          )}

          <footer className="text-center text-xs text-gray-500 dark:text-neutral-500 pt-4 pb-10">
            © {new Date().getFullYear()} WA Bot Admin Panel • Built with  Crazy Owner (SL CAT ᴇʜɪ ꜰɪʟᴇꜱ ™ 🇱🇰
)❤
          </footer>
        </main>
      </div>
    </div>
  );
}
