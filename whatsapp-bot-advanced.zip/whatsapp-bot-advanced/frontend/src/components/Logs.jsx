import { useEffect, useMemo, useState } from 'react'

export default function Logs() {
  const [logs, setLogs] = useState([])
  const [status, setStatus] = useState('')          // '', 'sent', 'failed'
  const [query, setQuery] = useState('')            // phone or text
  const [limit, setLimit] = useState(200)
  const [auto, setAuto] = useState(true)
  const [refreshIn, setRefreshIn] = useState(5)
  const [loading, setLoading] = useState(false)
  const [lastUpdated, setLastUpdated] = useState(null)

  const REFRESH_SEC = 5

  const load = async () => {
    try {
      setLoading(true)
      const q = new URLSearchParams()
      if (status) q.set('status', status)
      q.set('limit', String(limit))
      const r = await fetch('/api/logs?' + q.toString())
      const j = await r.json()
      setLogs(Array.isArray(j) ? j : [])
      setLastUpdated(Date.now())
      setRefreshIn(REFRESH_SEC)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [status, limit])

  // auto-refresh
  useEffect(() => {
    if (!auto) return
    const tick = setInterval(() => setRefreshIn((s) => (s > 1 ? s - 1 : REFRESH_SEC)), 1000)
    const t = setInterval(load, REFRESH_SEC * 1000)
    return () => { clearInterval(t); clearInterval(tick) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auto, status, limit])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return logs
    return logs.filter(l =>
      String(l.phone || '').toLowerCase().includes(q) ||
      String(l.message || '').toLowerCase().includes(q) ||
      String(l.scheduled_id || '').includes(q)
    )
  }, [logs, query])

  const stats = useMemo(() => {
    const total = filtered.length
    const sent = filtered.filter(x => x.status === 'sent').length
    const failed = filtered.filter(x => x.status === 'failed').length
    return { total, sent, failed }
  }, [filtered])

  const relTime = (isoMaybe) => {
    if (!isoMaybe) return ''
    const t = new Date(isoMaybe.endsWith('Z') ? isoMaybe : isoMaybe + 'Z').getTime()
    const d = Date.now() - t
    const a = Math.abs(d)
    const m = Math.round(a / 60000)
    if (m < 1) return d >= 0 ? '<1m ago' : 'in <1m'
    if (m < 60) return d >= 0 ? `${m}m ago` : `in ${m}m`
    const h = Math.round(m / 60)
    return d >= 0 ? `${h}h ago` : `in ${h}h`
  }

  const retry = async (scheduledId) => {
    if (!scheduledId) return
    if (!confirm(`Retry schedule #${scheduledId} in ~30s?`)) return
    const iso = new Date(Date.now() + 30000).toISOString()
    await fetch('/api/messages/' + scheduledId, {
      method:'PUT',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ status: 'pending', sendAt: iso })
    })
    load()
    document.dispatchEvent(new Event('reload-schedules'))
  }

  const exportCSV = () => {
    const head = ['id','scheduled_id','status','phone','message','send_at','created_at']
    const lines = [head.join(',')]
    filtered.forEach(l => {
      const vals = [
        l.id,
        l.scheduled_id ?? '',
        l.status ?? '',
        `"${String(l.phone||'').replace(/"/g,'""')}"`,
        `"${String(l.message||'').replace(/"/g,'""')}"`,
        l.send_at ?? '',
        l.created_at ?? '',
      ]
      lines.push(vals.join(','))
    })
    const blob = new Blob([lines.join('\n')], { type: 'text/csv' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'logs.csv'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  const copy = async (txt) => { try { await navigator.clipboard.writeText(txt) } catch {} }

  return (
    <div className="card">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold">Logs</h2>
        <div className="flex items-center gap-2">
          <input
            className="input max-w-56"
            placeholder="Search (phone / text / #id)"
            value={query}
            onChange={e=> (setQuery(e.target.value))}
          />
          <select className="input max-w-36" value={status} onChange={e=>setStatus(e.target.value)}>
            <option value="">All</option>
            <option value="sent">Sent</option>
            <option value="failed">Failed</option>
          </select>
          <select className="input max-w-28" value={String(limit)} onChange={e=>setLimit(Number(e.target.value)||200)}>
            <option value="100">100</option>
            <option value="200">200</option>
            <option value="500">500</option>
          </select>
          <button className="btn-secondary" onClick={exportCSV}>Export CSV</button>
          <button className="btn" onClick={load}>{loading ? 'Refreshing…' : 'Refresh'}</button>
        </div>
      </div>

      <div className="mt-2 flex items-center justify-between text-xs text-gray-500">
        <div className="flex items-center gap-2">
          <span>Total: <b>{stats.total}</b></span>
          <span className="hidden md:inline">• Sent: <b>{stats.sent}</b></span>
          <span className="hidden md:inline">• Failed: <b>{stats.failed}</b></span>
        </div>
        <div className="flex items-center gap-2">
          <label className="inline-flex items-center gap-2">
            <input type="checkbox" className="accent-blue-600" checked={auto} onChange={e=>setAuto(e.target.checked)} />
            Auto refresh {auto ? `in ${refreshIn}s` : ''}
          </label>
          <span>{lastUpdated ? `Updated ${new Date(lastUpdated).toLocaleTimeString()}` : ''}</span>
        </div>
      </div>

      <div className="mt-2 h-80 overflow-auto text-sm divide-y">
        {filtered.length === 0 && (
          <div className="py-6 text-center text-gray-500">{loading ? 'Loading…' : 'No logs'}</div>
        )}
        {filtered.map((l) => (
          <div key={`${l.id}-${l.created_at}`} className="py-2">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={'badge ' + (l.status === 'sent' ? 'badge-green' : 'badge-red')}>{l.status}</span>
                  <span className="text-gray-700">{l.phone}</span>
                  {l.scheduled_id != null && (
                    <span className="text-gray-400">#{l.scheduled_id}</span>
                  )}
                  <span className="text-gray-500">{l.created_at ? new Date(l.created_at + 'Z').toLocaleString() : ''}</span>
                  <span className="text-gray-400">({relTime(l.created_at)})</span>
                </div>
                <div className="mt-1 text-gray-800 whitespace-pre-wrap break-words">
                  {l.message}
                </div>
              </div>
              <div className="shrink-0 space-x-2">
                {l.status === 'failed' && l.scheduled_id && (
                  <button className="btn-secondary" onClick={()=>retry(l.scheduled_id)}>Retry 30s</button>
                )}
                {l.phone && (
                  <button className="btn-secondary" onClick={()=>copy(l.phone)}>Copy phone</button>
                )}
                <button
                  className="btn-secondary"
                  onClick={()=>copy(JSON.stringify(l, null, 2))}
                  title="Copy raw JSON"
                >
                  Copy JSON
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
