import { useEffect, useMemo, useState } from 'react'

export default function ScheduleTable() {
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState('') // '', 'pending', 'sent', 'failed'
  const [sortBy, setSortBy] = useState({ key: 'send_at', dir: 'asc' })
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [selected, setSelected] = useState(new Set()) // ids
  const [editing, setEditing] = useState(null) // id being edited
  const [editVal, setEditVal] = useState({ phone: '', sendAt: '', message: '' })

  const load = async () => {
    try {
      setLoading(true)
      const r = await fetch('/api/messages')
      const j = await r.json()
      setRows(Array.isArray(j) ? j : [])
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    const f = () => load()
    document.addEventListener('reload-schedules', f)
    const t = setInterval(load, 10000)
    return () => {
      document.removeEventListener('reload-schedules', f)
      clearInterval(t)
    }
  }, [])

  // ---------- helpers ----------
  const relTime = (dt) => {
    try {
      const ms = new Date(dt).getTime() - Date.now()
      const abs = Math.abs(ms)
      const mins = Math.round(abs / 60000)
      if (mins < 1) return ms >= 0 ? 'in <1m' : '<1m ago'
      if (mins < 60) return ms >= 0 ? `in ${mins}m` : `${mins}m ago`
      const hrs = Math.round(mins / 60)
      return ms >= 0 ? `in ${hrs}h` : `${hrs}h ago`
    } catch { return '-' }
  }

  const toggleSelect = (id) => {
    const s = new Set(selected)
    s.has(id) ? s.delete(id) : s.add(id)
    setSelected(s)
  }
  const clearSelection = () => setSelected(new Set())

  const handleSort = (key) => {
    setSortBy(prev => {
      if (prev.key === key) return { key, dir: prev.dir === 'asc' ? 'desc' : 'asc' }
      return { key, dir: 'asc' }
    })
  }

  // ---------- derived list ----------
  const filtered = useMemo(() => {
    let list = rows.slice()
    if (status) list = list.filter(x => x.status === status)
    if (query.trim()) {
      const q = query.trim().toLowerCase()
      list = list.filter(x =>
        String(x.phone).toLowerCase().includes(q) ||
        String(x.message || '').toLowerCase().includes(q) ||
        String(x.id).includes(q)
      )
    }
    list.sort((a,b) => {
      const { key, dir } = sortBy
      let av = a[key], bv = b[key]
      if (key === 'send_at' || key === 'sent_at') {
        av = av ? new Date(av).getTime() : 0
        bv = bv ? new Date(bv).getTime() : 0
      }
      if (av < bv) return dir === 'asc' ? -1 : 1
      if (av > bv) return dir === 'asc' ? 1 : -1
      return 0
    })
    return list
  }, [rows, query, status, sortBy])

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const pageRows = useMemo(() => {
    const start = (page - 1) * pageSize
    return filtered.slice(start, start + pageSize)
  }, [filtered, page, pageSize])

  useEffect(() => {
    if (page > totalPages) setPage(1)
  }, [totalPages])

  // ---------- actions ----------
  const delOne = async (id) => {
    if (!confirm('Delete #' + id + '?')) return
    await fetch('/api/messages/' + id, { method:'DELETE' })
    clearSelection()
    load()
  }
  const sendNow = async (id) => {
    if (!confirm('Send now #' + id + '?')) return
    const r = await fetch('/api/messages/' + id + '/send-now', { method:'POST' })
    if (!r.ok) {
      const j = await r.json().catch(()=>({}))
      alert('Failed: ' + (j.error || 'err'))
    }
    clearSelection()
    load()
  }
  const retryOne = async (id) => {
    const iso = new Date(Date.now() + 30000).toISOString()
    await fetch('/api/messages/' + id, {
      method:'PUT',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ status: 'pending', sendAt: iso })
    })
    clearSelection()
    load()
  }

  // bulk
  const bulk = async (fnName) => {
    if (selected.size === 0) return
    if (!confirm(`${fnName} ${selected.size} item(s)?`)) return
    const ids = Array.from(selected)
    if (fnName === 'delete') {
      await Promise.all(ids.map(id => fetch('/api/messages/' + id, { method:'DELETE' })))
    } else if (fnName === 'send_now') {
      await Promise.all(ids.map(id => fetch('/api/messages/' + id + '/send-now', { method:'POST' })))
    } else if (fnName === 'retry') {
      const iso = new Date(Date.now() + 30000).toISOString()
      await Promise.all(ids.map(id => fetch('/api/messages/' + id, {
        method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ status:'pending', sendAt: iso })
      })))
    }
    clearSelection()
    load()
  }

  const exportCSV = () => {
    const head = ['id','phone','message','send_at','status','sent_at','fail_reason']
    const lines = [head.join(',')]
    filtered.forEach(r => {
      const vals = [
        r.id,
        `"${String(r.phone).replace(/"/g,'""')}"`,
        `"${String(r.message||'').replace(/"/g,'""')}"`,
        r.send_at || '',
        r.status || '',
        r.sent_at || '',
        `"${String(r.fail_reason||'').replace(/"/g,'""')}"`,
      ]
      lines.push(vals.join(','))
    })
    const blob = new Blob([lines.join('\n')], { type: 'text/csv' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'schedules.csv'
    a.click()
    URL.revokeObjectURL(a.href)
  }

  // ---------- edit ----------
  const openEdit = (r) => {
    setEditing(r.id)
    setEditVal({
      phone: r.phone,
      sendAt: r.send_at ? new Date(new Date(r.send_at).getTime() - (new Date()).getTimezoneOffset()*60000).toISOString().slice(0,16) : '',
      message: r.message || ''
    })
  }
  const saveEdit = async (id) => {
    const iso = editVal.sendAt ? new Date(editVal.sendAt).toISOString() : null
    if (!editVal.phone || !iso || !editVal.message) { alert('Fill all fields'); return }
    await fetch('/api/messages/' + id, {
      method:'PUT',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ phone: editVal.phone.replace(/[^\d+]/g,''), sendAt: iso, message: editVal.message })
    })
    setEditing(null)
    load()
  }

  const copyPhone = async (p) => {
    try { await navigator.clipboard.writeText(p); } catch {}
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3 gap-2">
        <h2 className="text-lg font-semibold">Scheduled Messages</h2>
        <div className="flex flex-wrap items-center gap-2">
          <input
            className="input max-w-60"
            placeholder="Search (phone / text / id)"
            value={query}
            onChange={e=>{ setQuery(e.target.value); setPage(1) }}
          />
          <select className="input" value={status} onChange={e=>{ setStatus(e.target.value); setPage(1) }}>
            <option value="">All</option>
            <option value="pending">Pending</option>
            <option value="sent">Sent</option>
            <option value="failed">Failed</option>
          </select>
          <select className="input" value={pageSize} onChange={e=>{ setPageSize(Number(e.target.value)||10); setPage(1) }}>
            <option>10</option><option>25</option><option>50</option><option>100</option>
          </select>
          <button className="btn-secondary" onClick={exportCSV}>Export CSV</button>
          <button className="btn" onClick={load}>Refresh</button>
        </div>
      </div>

      {/* bulk bar */}
      {selected.size > 0 && (
        <div className="mb-3 flex items-center gap-2 text-sm">
          <span className="badge badge-amber">Selected: {selected.size}</span>
          <button className="btn" onClick={()=>bulk('send_now')}>Send now</button>
          <button className="btn-secondary" onClick={()=>bulk('retry')}>Retry</button>
          <button className="btn-secondary" onClick={()=>bulk('delete')}>Delete</button>
          <button className="btn-secondary" onClick={clearSelection}>Clear</button>
        </div>
      )}

      <div className="overflow-auto">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="text-left text-gray-600">
              <th className="p-2 w-8">
                <input
                  type="checkbox"
                  checked={selected.size>0 && pageRows.every(r=>selected.has(r.id))}
                  onChange={e=>{
                    const s = new Set(selected)
                    if (e.target.checked) pageRows.forEach(r=>s.add(r.id)); else pageRows.forEach(r=>s.delete(r.id))
                    setSelected(s)
                  }}
                />
              </th>
              <Th label="ID" k="id" sortBy={sortBy} onSort={handleSort} />
              <Th label="Phone" k="phone" sortBy={sortBy} onSort={handleSort} />
              <Th label="Send At" k="send_at" sortBy={sortBy} onSort={handleSort} />
              <Th label="Status" k="status" sortBy={sortBy} onSort={handleSort} />
              <th className="p-2">Actions</th>
            </tr>
          </thead>

          <tbody>
            {loading ? (
              <tr><td className="p-4 text-center text-gray-500" colSpan={6}>Loading…</td></tr>
            ) : pageRows.length === 0 ? (
              <tr><td className="p-4 text-center text-gray-500" colSpan={6}>No data</td></tr>
            ) : (
              pageRows.map(r => (
                <tr key={r.id} className="border-t align-top">
                  <td className="p-2"><input type="checkbox" checked={selected.has(r.id)} onChange={()=>toggleSelect(r.id)} /></td>
                  <td className="p-2">{r.id}</td>
                  <td className="p-2">
                    <div className="flex items-center gap-2">
                      <span>{r.phone}</span>
                      <button className="text-xs underline" onClick={()=>copyPhone(r.phone)}>copy</button>
                    </div>
                  </td>
                  <td className="p-2">
                    <div className="text-gray-900">{new Date(r.send_at).toLocaleString()}</div>
                    <div className="text-xs text-gray-500">{relTime(r.send_at)}</div>
                  </td>
                  <td className="p-2">
                    {r.status === 'sent' ? <span className="badge badge-green">sent</span>
                      : r.status === 'failed' ? <span className="badge badge-red">failed</span>
                      : <span className="badge badge-amber">pending</span>}
                    {r.fail_reason ? <div className="text-xs text-red-600 max-w-xs break-words mt-1">{r.fail_reason}</div> : null}
                  </td>
                  <td className="p-2 space-x-2">
                    <button onClick={()=>sendNow(r.id)} className="btn">Send now</button>
                    {r.status !== 'pending' && (
                      <button onClick={()=>retryOne(r.id)} className="btn-secondary">Retry</button>
                    )}
                    <button onClick={()=>delOne(r.id)} className="btn-secondary">Delete</button>
                    <button onClick={()=>openEdit(r)} className="btn-secondary">Edit</button>

                    {/* inline editor */}
                    {editing === r.id && (
                      <div className="mt-3 p-3 border rounded-xl bg-gray-50">
                        <div className="grid md:grid-cols-3 gap-2">
                          <input
                            className="input"
                            placeholder="phone"
                            value={editVal.phone}
                            onChange={e=>setEditVal(v=>({ ...v, phone: e.target.value }))}
                          />
                          <input
                            className="input"
                            type="datetime-local"
                            value={editVal.sendAt}
                            onChange={e=>setEditVal(v=>({ ...v, sendAt: e.target.value }))}
                          />
                          <button className="btn" onClick={()=>saveEdit(r.id)}>Save</button>
                          <textarea
                            className="input md:col-span-3"
                            rows={3}
                            value={editVal.message}
                            onChange={e=>setEditVal(v=>({ ...v, message: e.target.value }))}
                          />
                          <button className="btn-secondary md:col-span-3" onClick={()=>setEditing(null)}>Close</button>
                        </div>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* pagination */}
      <div className="mt-3 flex items-center justify-between text-sm">
        <div>Showing {(page-1)*pageSize + 1}-{Math.min(page*pageSize, filtered.length)} of {filtered.length}</div>
        <div className="flex items-center gap-2">
          <button className="btn-secondary" disabled={page<=1} onClick={()=>setPage(1)}>« First</button>
          <button className="btn-secondary" disabled={page<=1} onClick={()=>setPage(p=>Math.max(1, p-1))}>‹ Prev</button>
          <span>Page {page} / {totalPages}</span>
          <button className="btn-secondary" disabled={page>=totalPages} onClick={()=>setPage(p=>Math.min(totalPages, p+1))}>Next ›</button>
          <button className="btn-secondary" disabled={page>=totalPages} onClick={()=>setPage(totalPages)}>Last »</button>
        </div>
      </div>
    </div>
  )
}

function Th({ label, k, sortBy, onSort }) {
  const active = sortBy.key === k
  return (
    <th className="p-2 select-none">
      <button className="inline-flex items-center gap-1 hover:underline" onClick={()=>onSort(k)}>
        {label}
        <span className="text-xs text-gray-500">
          {active ? (sortBy.dir === 'asc' ? '▲' : '▼') : ''}
        </span>
      </button>
    </th>
  )
}
