import { useEffect, useMemo, useState } from 'react'

export default function StatusCard() {
  const [status, setStatus] = useState({ whatsapp_ready: false, has_qr: false })
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [lastUpdated, setLastUpdated] = useState(null)
  const [pingMs, setPingMs] = useState(null)
  const [refreshIn, setRefreshIn] = useState(5) // seconds

  const REFRESH_EVERY = 5 // seconds

  const load = async () => {
    try {
      setLoading(true)
      const t0 = performance.now()
      const [s, m] = await Promise.all([
        fetch('/api/status').then(r => r.json()),
        fetch('/api/messages').then(r => r.json()),
      ])
      setPingMs(Math.max(1, Math.round(performance.now() - t0)))
      setStatus(s || { whatsapp_ready: false, has_qr: false })
      setRows(Array.isArray(m) ? m : [])
      setLastUpdated(Date.now())
      setRefreshIn(REFRESH_EVERY)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    const tick = setInterval(() => setRefreshIn(x => (x > 1 ? x - 1 : REFRESH_EVERY)), 1000)
    const poll = setInterval(load, REFRESH_EVERY * 1000)
    return () => { clearInterval(poll); clearInterval(tick) }
  }, [])

  const kpi = useMemo(() => {
    const total = rows.length
    const pending = rows.filter(x => x.status === 'pending')
    const sent = rows.filter(x => x.status === 'sent').length
    const failed = rows.filter(x => x.status === 'failed').length
    const nextAt = pending
      .map(x => new Date(x.send_at))
      .sort((a, b) => a - b)[0]
    return { total, pending: pending.length, sent, failed, nextAt }
  }, [rows])

  const copyDebug = async () => {
    try {
      const dbg = {
        status,
        totals: kpi,
        lastUpdated: lastUpdated ? new Date(lastUpdated).toISOString() : null,
        pingMs,
      }
      await navigator.clipboard.writeText(JSON.stringify(dbg, null, 2))
    } catch {}
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-lg font-semibold">Status</h2>
        <div className="flex items-center gap-2">
          <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs
              ${status.whatsapp_ready ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
            <span className={`h-2 w-2 rounded-full ${status.whatsapp_ready ? 'bg-emerald-500' : 'bg-amber-500'}`} />
            {status.whatsapp_ready ? 'Connected' : 'Not connected'}
          </span>
          {status.has_qr && !status.whatsapp_ready && (
            <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs bg-blue-100 text-blue-700">
              QR ready
            </span>
          )}
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Kpi label="Total" value={kpi.total} />
        <Kpi label="Pending" value={kpi.pending} tone="amber" />
        <Kpi label="Sent" value={kpi.sent} tone="emerald" />
        <Kpi label="Failed" value={kpi.failed} tone="red" />
      </div>

      <div className="mt-3 text-sm text-gray-600">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-gray-500">Next send</div>
            <div>{kpi.nextAt ? kpi.nextAt.toLocaleString() : '—'}</div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500">
              {lastUpdated ? `Updated ${new Date(lastUpdated).toLocaleTimeString()} • ${pingMs ?? '-'} ms` : ''}
              {` • auto in ${refreshIn}s`}
            </span>
            <button onClick={load} className="btn-secondary">{loading ? 'Refreshing…' : 'Refresh'}</button>
            <button onClick={copyDebug} className="btn-secondary">Copy debug</button>
          </div>
        </div>
      </div>

      {!status.whatsapp_ready && (
        <div className="mt-3 text-xs text-gray-600">
          <ul className="list-disc list-inside">
            <li>Open WhatsApp → <b>Linked Devices</b> → <b>Link a device</b> and scan the QR.</li>
            <li>QR not visible? Try the “Refresh” button or the QR card refresh.</li>
          </ul>
        </div>
      )}
    </div>
  )
}

function Kpi({ label, value, tone }) {
  const ring = tone === 'emerald' ? 'ring-emerald-200'
            : tone === 'amber' ? 'ring-amber-200'
            : tone === 'red' ? 'ring-red-200'
            : 'ring-gray-200'
  return (
    <div className={`rounded-2xl border border-gray-200 p-3 ring-1 ${ring}`}>
      <div className="text-xs text-gray-500">{label}</div>
      <div className="text-xl font-semibold">{value}</div>
    </div>
  )
}
