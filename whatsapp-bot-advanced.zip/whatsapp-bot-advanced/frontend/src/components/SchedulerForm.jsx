import { useMemo, useState } from 'react'

export default function SchedulerForm() {
  const [phone, setPhone] = useState('')
  const [sendAt, setSendAt] = useState('')            // HTML datetime-local (local TZ)
  const [message, setMessage] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [err, setErr] = useState(null)
  const [ok, setOk] = useState(null)
  const [defaultCC, setDefaultCC] = useState('94')     // Sri Lanka by default

  // --- helpers ---
  const normalizePhone = (raw) => {
    if (!raw) return ''
    let d = String(raw).replace(/[^\d+]/g, '')
    // strip leading +
    if (d.startsWith('+')) d = d.slice(1)
    // if starts with 0 -> assume local, replace first 0 with default country code
    if (d.startsWith('0')) d = defaultCC + d.slice(1)
    return d
  }

  const validPhone = (p) => /^\d{9,15}$/.test(p)      // rough E.164-ish
  const toUtcIso = (localStr) => {
    if (!localStr) return null
    const dt = new Date(localStr)                     // browser interprets as local
    if (Number.isNaN(+dt)) return null
    return dt.toISOString()
  }

  const nowLocalISO = () => {
    const d = new Date()
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset()) // trick to format as local for input
    return d.toISOString().slice(0,16)
  }

  const setPreset = (minsFromNow) => {
    const d = new Date()
    d.setMinutes(d.getMinutes() + minsFromNow)
    // format for datetime-local (YYYY-MM-DDTHH:mm)
    const z = new Date(d.getTime() - d.getTimezoneOffset()*60000).toISOString().slice(0,16)
    setSendAt(z)
  }

  const setTomorrowAt = (h=9, m=0) => {
    const d = new Date()
    d.setDate(d.getDate() + 1)
    d.setHours(h, m, 0, 0)
    const z = new Date(d.getTime() - d.getTimezoneOffset()*60000).toISOString().slice(0,16)
    setSendAt(z)
  }

  const preview = useMemo(() => {
    const norm = normalizePhone(phone)
    const utc = toUtcIso(sendAt)
    return {
      phone: norm,
      phoneOk: validPhone(norm),
      localText: sendAt ? new Date(sendAt).toLocaleString() : '—',
      utcText: utc ? new Date(utc).toISOString() : '—',
      inFuture:
        utc ? new Date(utc).getTime() > Date.now() : false,
      chars: message.length
    }
  }, [phone, sendAt, message, defaultCC])

  const submit = async (e) => {
    e.preventDefault()
    setErr(null); setOk(null)

    const norm = normalizePhone(phone)
    const iso = toUtcIso(sendAt)

    if (!norm || !iso || !message) {
      return setErr('Please fill all fields.')
    }
    if (!validPhone(norm)) {
      return setErr('Invalid phone format. Use international (e.g., 9477xxxxxxx).')
    }
    if (new Date(iso).getTime() < Date.now() - 5000) {
      return setErr('Send time must be in the future.')
    }

    try {
      setSubmitting(true)
      const r = await fetch('/api/messages', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ phone: norm, sendAt: iso, message })
      })
      if (!r.ok) {
        const j = await r.json().catch(()=>({}))
        throw new Error(j.error || 'Request failed')
      }
      setOk('Scheduled ✅')
      setPhone(''); setSendAt(''); setMessage('')
      document.dispatchEvent(new Event('reload-schedules'))
    } catch (e) {
      setErr(e.message || 'Failed to schedule')
    } finally {
      setSubmitting(false)
    }
  }

  const useTemplate = (type) => {
    if (type === 'greet') {
      setMessage(prev => prev
        ? prev
        : `Hello! 👋\nThis is a reminder from our WhatsApp bot.\nHave a great day!`)
    } else if (type === 'appointment') {
      setMessage(prev => prev
        ? prev
        : `Hi! 👋\nThis is a reminder for your appointment on {{date}} at {{time}}.\nReply if you need to reschedule.`)
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      {/* notices */}
      {err && <div className="rounded-xl border border-red-200 bg-red-50 text-red-700 px-3 py-2 text-sm">{err}</div>}
      {ok &&  <div className="rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 px-3 py-2 text-sm">{ok}</div>}

      <div className="grid md:grid-cols-3 gap-4">
        {/* phone */}
        <div>
          <label className="label">Phone (international)</label>
          <input
            className="input"
            value={phone}
            onChange={e=>setPhone(e.target.value)}
            placeholder="9477xxxxxxx or +9477xxxxxxx"
            autoComplete="tel"
          />
          <div className="mt-1 flex items-center gap-2 text-xs text-gray-500">
            <span>Default CC:</span>
            <input
              className="input !px-2 !py-1 !w-20"
              value={defaultCC}
              onChange={e=>setDefaultCC(e.target.value.replace(/[^\d]/g,''))}
            />
            <span className={`${preview.phoneOk ? 'text-emerald-600' : 'text-amber-600'}`}>
              {preview.phone ? `Normalized: ${preview.phone}` : '—'}
            </span>
          </div>
        </div>

        {/* datetime */}
        <div>
          <label className="label">Send Date & Time (local)</label>
          <input
            className="input"
            type="datetime-local"
            value={sendAt}
            onChange={e=>setSendAt(e.target.value)}
            min={nowLocalISO()}
          />
          <div className="mt-2 flex flex-wrap gap-2">
            <button type="button" className="btn-secondary" onClick={()=>setPreset(15)}>+15m</button>
            <button type="button" className="btn-secondary" onClick={()=>setPreset(60)}>+1h</button>
            <button type="button" className="btn-secondary" onClick={()=>setPreset(180)}>+3h</button>
            <button type="button" className="btn-secondary" onClick={()=>setTomorrowAt(9,0)}>Tomorrow 09:00</button>
          </div>
        </div>

        {/* templates */}
        <div>
          <label className="label">Templates</label>
          <div className="flex gap-2">
            <button type="button" className="btn-secondary" onClick={()=>useTemplate('greet')}>Greeting</button>
            <button type="button" className="btn-secondary" onClick={()=>useTemplate('appointment')}>Appointment</button>
          </div>
        </div>
      </div>

      {/* message */}
      <div>
        <label className="label">Message</label>
        <textarea
          className="input"
          rows={5}
          value={message}
          onChange={e=>setMessage(e.target.value)}
          placeholder="Type your message..."
        />
        <div className="mt-1 text-xs text-gray-500 flex justify-between">
          <span>Supports new lines. Simple placeholders like <code className="px-1 rounded bg-gray-100">{"{{date}}"}</code> are okay.</span>
          <span>{preview.chars} chars</span>
        </div>
      </div>

      {/* preview */}
      <div className="rounded-2xl border border-gray-200 p-3 text-sm bg-white">
        <div className="grid md:grid-cols-3 gap-3">
          <div>
            <div className="text-gray-500">To</div>
            <div className={`${preview.phoneOk ? 'text-gray-900' : 'text-amber-700'}`}>
              {preview.phone || '—'}
            </div>
          </div>
          <div>
            <div className="text-gray-500">Local time</div>
            <div>{preview.localText}</div>
          </div>
          <div>
            <div className="text-gray-500">UTC</div>
            <div>{preview.utcText}</div>
          </div>
        </div>
        {!preview.inFuture && sendAt && (
          <div className="mt-2 text-amber-700">⚠ Selected time is not in the future.</div>
        )}
      </div>

      <div className="flex gap-2">
        <button className="btn" type="submit" disabled={submitting}>
          {submitting ? 'Scheduling…' : 'Add Schedule'}
        </button>
        <button
          type="button"
          className="btn-secondary"
          onClick={() => { setPhone(''); setSendAt(''); setMessage(''); setErr(null); setOk(null); }}
          disabled={submitting}
        >
          Clear
        </button>
      </div>
    </form>
  )
}
