import { useEffect, useState } from 'react'

/**
 * Fire a toast from anywhere:
 * document.dispatchEvent(new CustomEvent('app:toast', { detail: { message: 'Saved!', type: 'success' }}))
 * Types: 'success' | 'error' | 'info'
 */
export default function Toaster() {
  const [items, setItems] = useState([]) // {id, message, type}

  useEffect(() => {
    const onToast = (e) => {
      const id = crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random())
      const t = e.detail?.type || 'info'
      const msg = e.detail?.message || ''
      const ttl = e.detail?.ttl ?? 3000
      setItems((prev) => [...prev, { id, message: msg, type: t }])
      setTimeout(() => setItems((prev) => prev.filter(i => i.id !== id)), ttl)
    }
    document.addEventListener('app:toast', onToast)
    return () => document.removeEventListener('app:toast', onToast)
  }, [])

  const tone = (t) =>
    t === 'success' ? 'bg-emerald-600' :
    t === 'error'   ? 'bg-red-600' :
                      'bg-slate-800'

  return (
    <div className="fixed z-[9999] top-4 right-4 space-y-2">
      {items.map(i => (
        <div
          key={i.id}
          className={`text-white rounded-xl px-3 py-2 shadow-lg ${tone(i.type)} max-w-xs`}
        >
          {i.message}
        </div>
      ))}
    </div>
  )
}
