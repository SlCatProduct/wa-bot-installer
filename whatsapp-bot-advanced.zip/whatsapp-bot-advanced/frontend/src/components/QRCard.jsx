import { useEffect, useState } from 'react'

export default function QRCard() {
  const [qr, setQr] = useState(null)
  const [connected, setConnected] = useState(false)
  const [hasQR, setHasQR] = useState(false)
  const [loading, setLoading] = useState(false)
  const [lastUpdated, setLastUpdated] = useState(null)

  const load = async () => {
    try {
      setLoading(true)
      // get status first
      const s = await fetch('/api/status').then(r => r.json())
      setConnected(!!s.whatsapp_ready)
      setHasQR(!!s.has_qr)

      // fetch qr only when not connected and server says it has one
      if (!s.whatsapp_ready && s.has_qr) {
        const q = await fetch('/api/qr').then(r => r.json())
        setQr(q.qrDataUrl || null)
      } else {
        setQr(null)
      }
      setLastUpdated(Date.now())
    } catch (e) {
      console.error('QR load failed', e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])
  // poll until connected
  useEffect(() => {
    if (connected) return
    const t = setInterval(load, 5000)
    return () => clearInterval(t)
  }, [connected])

  const download = () => {
    if (!qr) return
    const a = document.createElement('a')
    a.href = qr
    a.download = 'wa-qr.png'
    a.click()
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-lg font-semibold">Scan QR to Connect</h2>
        <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs
          ${connected ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
          <span className={`h-2 w-2 rounded-full ${connected ? 'bg-emerald-500' : 'bg-amber-500'}`} />
          {connected ? 'Connected' : 'Waiting'}
        </span>
      </div>

      <div className="border rounded-2xl w-72 h-72 mx-auto flex items-center justify-center overflow-hidden bg-white">
        {loading ? (
          <div className="animate-pulse w-full h-full bg-gray-100" />
        ) : qr ? (
          <img src={qr} alt="WhatsApp QR" className="w-72 h-72 object-contain" />
        ) : (
          <div className="text-center p-4 text-gray-500 text-sm">
            {connected
              ? 'Phone is already linked.'
              : hasQR
              ? 'Fetching QR…'
              : 'No QR yet. If session is initializing, a QR will appear soon.'}
          </div>
        )}
      </div>

      <div className="mt-3 flex items-center gap-2">
        <button onClick={load} className="btn">Refresh</button>
        <button onClick={download} className="btn-secondary" disabled={!qr}>Download PNG</button>
        {qr && (
          <a href={qr} target="_blank" rel="noreferrer" className="btn-secondary">Open large</a>
        )}
        <span className="ml-auto text-xs text-gray-500">
          {lastUpdated ? `Updated ${new Date(lastUpdated).toLocaleTimeString()}` : ''}
        </span>
      </div>

      {!connected && (
        <ol className="mt-3 text-xs text-gray-600 list-decimal list-inside space-y-1">
          <li>Open WhatsApp on your phone</li>
          <li>Menu → <b>Linked Devices</b> → <b>Link a device</b></li>
          <li>Scan the QR shown above</li>
        </ol>
      )}
    </div>
  )
}
